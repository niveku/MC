
void ErrExit (int code)
{
  printf ("Error: %s\n", errorMsg[code]);
  exit (0);
}

